const Role = {
  investor: 10,
  startup: 10,
};

export const roleType = [10, 20];
export const industryTypes = [
  "Agriculture",
  "Automotive",
  "Construction",
  "Education",
  "Finance",
  "Healthcare",
  "Hospitality",
  "Information Technology",
  "Manufacturing",
  "Real Estate",
  "Retail",
  "Transportation",
  "Utilities"
];

export const investorType = [
  "Angle Investor",
  "Venture Capitalist (VC)",
  "Family investor",
];
